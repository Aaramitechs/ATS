({
    
    // if quick action is used from account, set that lookup field
    // if quick action is used from global, keep null
    handleOnload: function(component, event, helper) {
        let parentAccountId = component.get("v.recordId");
        var accId = '';
        if(!$A.util.isEmpty(parentAccountId)){
            const action = component.get('c.getAccount');
            action.setParams({
                id: parentAccountId
            });
            action.setCallback(this, function(response){
                const res = JSON.parse(response.getReturnValue());
                component.set('v.selectedAccount', res);
            });
            $A.enqueueAction(action);
            accId = parentAccountId;
        }
        component.set('v.parentAccount', accId);
        //component.set('v.selectedAccount', accId);
        component.set('v.accRecId', accId);
    },
    
    handleSubmit: function(component, event, helper) {
        event.preventDefault();       // stop the form from submitting
        var fields = event.getParam('fields');
        var acc = component.get('v.selectedAccount');
        if(!$A.util.isEmpty(acc)){
            fields.Account__c = acc.Id;
        }
        var ise = component.get('v.selectedISE');
        if(!$A.util.isEmpty(ise)){
            fields.ISE__c = ise.Id;
        }        
        var proj = component.get('v.selectedProject');
        if(!$A.util.isEmpty(proj)){
            fields.Project__c = proj.Id;
        }
        var sr = component.get('v.selectedSalesRep');
        if(!$A.util.isEmpty(sr)){
            fields.User__c = sr.Id;
        }
        component.find('qualityFeedbackForm').submit(fields);
    },
    
    handleSuccess : function(component, event, helper) {
        $A.get("e.force:closeQuickAction").fire();
        var newRecord = event.getParams().response;
        // navigate to new record on successful save
        var navEvt = $A.get("e.force:navigateToSObject");
        navEvt.setParams({
            "recordId": newRecord.id,
            "slideDevName": "detail"
        });
        navEvt.fire();
    } 
})