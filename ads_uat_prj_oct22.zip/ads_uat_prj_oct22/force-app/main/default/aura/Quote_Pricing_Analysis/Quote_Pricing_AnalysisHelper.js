({
	calculateTotals : function(component, event, helper){
		var lineList = component.get("v.lineList");
		var selectedQuote = component.get("v.selectedQuote");

		var selectedLines = [];
		for(var i = 0; i < lineList.length; i++){
			if(lineList[i].Quote_Name__c == selectedQuote){
				selectedLines.push(lineList[i]);
			}
		}

		var requestedTotal = 0;
		var recommendedTotal = 0;
		for(var i = 0; i < selectedLines.length; i++){
			var currLine = selectedLines[i];

			if(i == 0){
				component.set("v.preparedForId", currLine.Quote_Prepared_For__c);
				component.set("v.preparedForName", currLine.Quote_Prepared_For__r.Name);
			}
			var recommendedPrice = isNaN(currLine.Recommended_Price__c) ? 0.0 : currLine.Recommended_Price__c;
			var requestedPrice = isNaN(currLine.Requested_Price__c) ? 0.0 : currLine.Requested_Price__c;

			if(requestedPrice != 0.0){
				requestedTotal += requestedPrice * currLine.Quantity__c;
			}
			else{
				requestedTotal += recommendedPrice * currLine.Quantity__c;
			}

			recommendedTotal += recommendedPrice  * currLine.Quantity__c;
		}

		var difference = recommendedTotal - requestedTotal;
		var percentDiff = ((recommendedTotal / requestedTotal) - 1) * 100;
		percentDiff = isNaN(percentDiff) || !isFinite(percentDiff) ? 0.0 : ((recommendedTotal / requestedTotal) - 1) * 100;

		component.set("v.requestedQuoteTotal", requestedTotal);
		component.set("v.recommendQuoteTotal", recommendedTotal);
		component.set("v.totalDifference", difference);
		component.set("v.percentDifference", percentDiff);
	},

	buildLine: function(component, event, helper, lineInfo){

		lineInfo.Recommended_Price__c = isNaN(lineInfo.Recommended_Price__c) ? 0.0 : lineInfo.Recommended_Price__c;
		lineInfo.Requested_Price__c = isNaN(lineInfo.Requested_Price__c) ? 0.0 : lineInfo.Requested_Price__c;

		var percentDiff = ((lineInfo.Recommended_Price__c/lineInfo.Requested_Price__c) - 1) * 100;
		lineInfo.PercentChange = isNaN(percentDiff) || !isFinite(percentDiff) ? 0.0 : percentDiff;

		console.log(lineInfo.Product_Description__c);
		var element = document.createElement( 'div' );
		console.log(element);
		element.innerHTML = lineInfo.Product_Description__c;
		console.log(element.textContent);
		lineInfo.Product_Description__c = element.textContent.substring(0, 255);
		console.log(lineInfo);

		return lineInfo;
	},

	sortHelper: function(component, event, sortFieldName) {
		var currentDir = component.get("v.arrowDirection");

		var mod = 0;
		if (currentDir == 'arrowdown') {
			// set the arrowDirection attribute for conditionally rendred arrow sign
			component.set("v.arrowDirection", 'arrowup');
			// set the isAsc flag to true for sort in Assending order.
			component.set("v.isAsc", true);
			mod = 1;
		} else {
			component.set("v.arrowDirection", 'arrowdown');
			component.set("v.isAsc", false);
			mod = -1;
		}

		// sort lines
		var lines = component.get("v.lineList", lines);
		lines.sort(function(line1, line2){
			if(line1[sortFieldName] > line2[sortFieldName]){
				return 1 * mod;
			}
			else if(line1[sortFieldName] < line2[sortFieldName]){
				return -1 * mod;
			}
			return 0;
		});

		component.set("v.lineList", lines);
	}
})