({
	init : function(component, event, helper) {
		var action = component.get("c.getProjectQuoteAnalyses");
		action.setParams({ projectId : component.get("v.recordId") });

		action.setCallback(this, function(response){
				var state = response.getState();
				if(state = "SUCCESS"){
					var ret = response.getReturnValue();
					var quotes = [];
					var lines = [];
					var count = 0;
					for(var key in ret){
						quotes.push(key);
						if(count == 0){
							component.set("v.selectedQuote", key);
						}

						for(var i = 0; i < ret[key].length; i++){
							var line = helper.buildLine(component, event, helper, ret[key][i]);
							lines.push(line);
						}

						count++;
					}
					component.set("v.quoteList", quotes);
					component.set("v.lineList", lines);

					helper.calculateTotals(component, event, helper);
					component.set("v.selectedTabsoft", 'PercentChange');
					helper.sortHelper(component, event, 'PercentChange');
				}
		});
		$A.enqueueAction(action);
	},

	recalculateTotals : function(component, event, helper){
		helper.calculateTotals(component, event, helper);
	},

	sortProductCode: function(component, event, helper) {
       component.set("v.selectedTabsoft", 'Product_Code__c');
       helper.sortHelper(component, event, 'Product_Code__c');
    },

	sortProductDescription: function(component, event, helper) {
       component.set("v.selectedTabsoft", 'Product_Description__c');
       helper.sortHelper(component, event, 'Product_Description__c');
    },

	sortQuantity: function(component, event, helper) {
       component.set("v.selectedTabsoft", 'Quantity__c');
       helper.sortHelper(component, event, 'Quantity__c');
    },

	sortRequestedPrice: function(component, event, helper) {
       component.set("v.selectedTabsoft", 'Requested_Price__c');
       helper.sortHelper(component, event, 'Requested_Price__c');
    },

	sortRecommendedPrice: function(component, event, helper) {
       component.set("v.selectedTabsoft", 'Recommended_Price__c');
       helper.sortHelper(component, event, 'Recommended_Price__c');
    },

	sortPercentChange: function(component, event, helper) {
       component.set("v.selectedTabsoft", 'PercentChange');
       helper.sortHelper(component, event, 'PercentChange');
    },

})