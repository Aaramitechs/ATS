({    searchHelper : function(component,event,inputKey) {
        const action = component.get("c.fetchLookUpValues");
        action.setParams({
            'searchKeyWord': inputKey,
            'ObjectName' : component.get("v.objectAPIName")
        });
        action.setCallback(this, function(response) {
            $A.util.removeClass(component.find("mySpinner"), "slds-show");
            const state = response.getState();
            if (state === "SUCCESS") {
                const storeResponse = response.getReturnValue();
                if (storeResponse.length == 0) {
                    component.set("v.Message", 'No Result Found...');
                } else {
                    component.set("v.Message", '');
                }
                component.set("v.listOfSearchRecords", storeResponse);
            }

        });
        $A.enqueueAction(action);
    },

    createPill: function(component, searchKey){
        let records = component.get('v.selectedRecords');
        records.push(searchKey);
        component.set('v.selectedRecords', records);
        component.set("v.SearchKeyWord", null);
    },

    displaySelected: function(component){
        component.set("v.listOfSearchRecords", null);
        const forclose = component.find("searchRes");
        $A.util.addClass(forclose, 'slds-is-close');
        $A.util.removeClass(forclose, 'slds-is-open');
    }
})