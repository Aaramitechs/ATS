({
    reload: function(component, event, helper){
        if (!$A.util.isEmpty(component.get('v.selectedRecord'))){
            helper.displaySelected(component);
        } 
    },

    onfocus : function(component,event,helper){
        $A.util.addClass(component.find("mySpinner"), "slds-show");
        const forOpen = component.find("searchRes");
        $A.util.addClass(forOpen, 'slds-is-open');
        $A.util.removeClass(forOpen, 'slds-is-close');
        const inputKey = '';
        helper.searchHelper(component,event,inputKey);

    },
    onblur : function(component,event,helper){
        const searchKey = component.get('v.SearchKeyWord');        
        if (searchKey != null && searchKey.trim() != '' && searchKey.includes('@') && searchKey.includes('.')){
            helper.createPill(component, searchKey);
        }
        helper.displaySelected(component);
    },

    keyPressController : function(component, event, helper) {
        const inputKey = component.get("v.SearchKeyWord");
        if (inputKey.length > 0 ){
            const forOpen = component.find("searchRes");
            $A.util.addClass(forOpen, 'slds-is-open');
            $A.util.removeClass(forOpen, 'slds-is-close');
            helper.searchHelper(component,event,inputKey);
        } else  {
            component.set("v.listOfSearchRecords", null );
            const forclose = component.find("searchRes");
            $A.util.addClass(forclose, 'slds-is-close');
            $A.util.removeClass(forclose, 'slds-is-open');
        }
    },

    checkEnter : function(component, event, helper){
        if (event.which == 13){
            let searchKey = component.get('v.SearchKeyWord');
            if (searchKey != '' && searchKey != null && searchKey.trim() != '' && searchKey.includes('@') && searchKey.includes('.')){
                helper.createPill(component, searchKey);
                helper.displaySelected(component);
            }
        }
    },

    clear : function(component,event,helper){
        const index = event.getParams().name; 
        const records = component.get('v.selectedRecords');
        records.splice(index, 1);
        component.set('v.selectedRecords', records);
    },

    selectRecord : function (component, event, helper){
        const index = event.target.getAttribute("data-selected-Index");
        const records = component.get('v.listOfSearchRecords');
        const selectedRecord = records[index];
        if (selectedRecord != null){
            component.set('v.selectedRecord', selectedRecord);
            helper.createPill(component, selectedRecord.Email);
        }
    }
})