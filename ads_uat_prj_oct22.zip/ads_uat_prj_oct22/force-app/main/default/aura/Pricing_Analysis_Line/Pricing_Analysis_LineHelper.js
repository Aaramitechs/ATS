({
	helperMethod : function() {
	}
})