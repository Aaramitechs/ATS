({
	init : function(component, event, helper) {
		/*var lineInfo = component.get("v.lineInfo");

		var recommendedPrice = isNaN(lineInfo.Recommended_Price__c) ? 0.0 : lineInfo.Recommended_Price__c;
		var requestedPrice = isNaN(lineInfo.Requested_Price__c) ? 0.0 : lineInfo.Requested_Price__c;

		var percentDiff = ((recommendedPrice/requestedPrice) - 1) * 100;
		console.log('infinity line');
		console.log(percentDiff);
		percentDiff = isNaN(percentDiff) || !isFinite(percentDiff) ? 0.0 : percentDiff;

		console.log('line vals');
		console.log(lineInfo);
		console.log(recommendedPrice);
		console.log(requestedPrice);

		component.set("v.recommendPrice", recommendedPrice);
		component.set("v.requestedPrice", requestedPrice);
		component.set("v.percentDifference", percentDiff);*/
	}
})