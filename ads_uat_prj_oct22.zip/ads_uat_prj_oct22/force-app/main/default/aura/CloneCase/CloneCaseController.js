({
	doInit : function(component, event, helper) {
        console.log('1111');
        var action = component.get("c.initializeCase");
        console.log('14');
        console.log('action15');
        
        action.setCallback(this, function(data) {
            console.log(data.getReturnValue());
            console.log('here');
            component.set("v.caseRec", data.getReturnValue());
        });
        $A.enqueueAction(action);
    },
    
    handleSave : function(component, event, helper){
        document.getElementById("Accspinner").style.display = "block";
        var revision = component.find("revision");
        var revisionValue = revision.get("v.value");
        var link = component.find("link");
        var linkValue = link.get("v.value");
        var notes = component.find("notes");
        var notesValue = notes.get("v.value");
        var reason = component.find("reason");
        var reasonValue = reason.get("v.value");
        var reasonDate = component.find("reasonDate");
        var reasonDateValue = reason.get("v.value");
        if(!revisionValue || revisionValue == '--- None ---'){
            document.getElementById('revisionError').style.display = 'block';
            document.getElementById("Accspinner").style.display = "none";
            revisionValue = false;
        }
        else{
            document.getElementById('revisionError').style.display = 'none';
        }
        
        if(!notesValue){
            document.getElementById('notesError').style.display = 'block';
            document.getElementById("Accspinner").style.display = "none";
        }
        else{
            document.getElementById('notesError').style.display = 'none';
        }
        if(!revisionValue || !notesValue){
            console.log('invalid form');
            return;
        }
        // Prepare the action to create the new contact
        var cloneCaseAction = component.get("c.cloneCase");
        var cRec = component.get("v.caseRec");
        cRec.sobjectType = 'Case';
        var cRecSerialized = JSON.stringify(cRec);
        var cId = component.get("v.recordId");
        
        cloneCaseAction.setParams({
            "caseSerialized": cRecSerialized,
            "caseId": cId
        });
        
        console.log('callback');
        // Configure the response handler for the action
        cloneCaseAction.setCallback(this, function(response) {
            var state = response.getState();
            console.log('response: '+ response);
            console.log('return val: ' + response.getReturnValue());
            var caseId = response.getReturnValue();
            if(state === "SUCCESS") {
                document.getElementById("Accspinner").style.display = "none";
                console.log('success');
				// navigate to new record
				var navEvt = $A.get("e.force:navigateToSObject");
                navEvt.setParams({
                  "recordId": caseId,
                  "slideDevName": "Detail"
                });
                navEvt.fire();
            }
            else if (state === "ERROR") {
                document.getElementById("Accspinner").style.display = "none";
                console.log('Problem saving case, response state: ' + state);
                let errors = response.getError();
                console.log(errors);
                let message = 'Unknown error'; // Default error message
                // Retrieve the error message sent by the server
                if (errors && Array.isArray(errors) && errors.length > 0) {
                    message = errors[0].message;
                }
                // Display the message
                console.error(message);
                // Configure error toast
                let toastParams = {
                    title: "Error",
                    message: message, // Default error message
                    type: "error"
                };
                // Pass the error message if any
                if (errors && Array.isArray(errors) && errors.length > 0) {
                    toastParams.message = errors[0].message;
                }
                // Fire error toast
                let toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams(toastParams);
                toastEvent.fire();
            }
            else {
                console.log('other error');
                document.getElementById("Accspinner").style.display = "none";
                // Configure error toast
                let toastParams = {
                    title: "Error",
                    message: "Unknown error", // Default error message
                    type: "error"
                };
                // Pass the error message if any
                if (errors && Array.isArray(errors) && errors.length > 0) {
                    toastParams.message = errors[0].message;
                }
                // Fire error toast
                let toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams(toastParams);
                toastEvent.fire();
            }
        });

        // Send the request to create the new Engineering Service Requests
        $A.enqueueAction(cloneCaseAction);
    }
})