({
	init: function(component, event, helper){
        const action = component.get('c.renderTemplate');
        action.setParams({
            recordId: component.get('v.recordId')
        });

        action.setCallback(this, function(response){
            const res = JSON.parse(response.getReturnValue()); 
            component.set('v.subject', res.Subject);
            component.set('v.template', res.Template);
            var arr = [];
            var ccarr = [];
            var bccarr = [];
            arr.push(res.ToId.Email);
            ccarr.push(res.CCId.Email);
            bccarr.push(res.BCCId.Email);
            component.set('v.bccList', bccarr);
            component.set('v.toList', arr);
            component.set('v.ccList', ccarr);
            component.set('v.sendto', res.ToId);
            component.set('v.ccto', res.CCId);
            component.set('v.attachment', res.Attachment);
        });
        $A.enqueueAction(action);
        
    },
    
    submit: function(component, event, helper){
        const action = component.get('c.sendQuoteDocument');
        var to = component.get('v.sendto');
        var cc = component.get('v.sendcc');
        var toList = {
            to : component.get('v.toList'),
            cc : component.get('v.ccList'),
            bcc : component.get('v.bccList'),
            attachments: component.get('v.attachments')
        };

        var toout = JSON.stringify(toList);
        action.setParams({
            recordId: component.get('v.recordId'),
            template: component.get('v.template'),
            to: toout,
            subject: component.get('v.subject')
        });

        action.setCallback(this, function(response){
            const res = JSON.parse(response.getReturnValue()); 

        });
        $A.enqueueAction(action);
        
        var resultsToast = $A.get("e.force:showToast");
        resultsToast.setParams({
            "title": "Success!",
            "message": "Email Sent"
        });
        resultsToast.fire();

        // Close the action panel
        var dismissActionPanel = $A.get("e.force:closeQuickAction");
        dismissActionPanel.fire();
        
    },

    handleFileChange: function(component, event, helper){
        const file = event.getSource().get('v.files')[0];
        let fileReader = new FileReader();
        fileReader.onload = $A.getCallback(function(){
            let contents = fileReader.result;
            let base64 = 'base64,';
            let dataStart = contents.indexOf(base64) + base64.length;
            contents = contents.substring(dataStart);
            helper.formatAttachment(component, file, contents);
        });
        fileReader.readAsDataURL(file);
    },

    delete: function(component, event, helper){
        const index = event.getParams().name; 
        let attachments = component.get('v.attachments');
        const action = component.get('c.deleteAttachment');
        action.setParams({
            fileIds: [attachments[index].Id]
        });
        action.setCallback(this, function(response){
            const res = JSON.parse(response.getReturnValue());
            if (res.success){
                attachments.splice(index, 1);
                component.set('v.attachments', attachments);
            } else {
                helper.showToast('Error', res.error);
            }
        });
        $A.enqueueAction(action);
    },
    
    closeModal : function(component, event, helper){
    	$A.get("e.force:closeQuickAction").fire();
	}

})