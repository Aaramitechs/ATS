({
    showToast: function (title, message){
        const toastEvent = $A.get('e.force:showToast');
        toastEvent.setParams({
            'title': title,
            'message': message
        });
        toastEvent.fire();
    },
	formatAttachment: function(component, file, contents){
        let startPosition = 0;
        let endPosition = Math.min(contents.length, startPosition + 75000000);
        this.uploadAttachment(component, file, contents.substring(startPosition, endPosition));
    },

    uploadAttachment: function(component, file, attachmentBody){
        const action = component.get('c.saveAttachment');
        action.setParams({
            parentId: component.get('v.recordId'),
            name: file.name,
            base64Data: encodeURIComponent(attachmentBody),
            type: file.type
        });
        action.setCallback(this, function(response){
            console.log(response.getReturnValue());
            console.log(response.getError());
            const res = JSON.parse(response.getReturnValue());
            if (res.success){
                let attachments = component.get('v.attachments');
                attachments.push(res.file);
                component.set('v.attachments', attachments);
            } else {
                this.showToast('Error', res.Error);
            }
        });
        $A.enqueueAction(action);
    },
})