({
	doInit : function(component, event, helper) {
		var today = new Date();
        today.setDate(today.getDate()+90);
		var date = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate();
        component.set("v.today", date);
        
        var action = component.get("c.getCaseFields");
        //var caseId = component.get("v.recordId");
        action.setParams({
            "caseId": component.get("v.recordId")
        });
        action.setCallback(this, function(response){
            const res = JSON.parse(response.getReturnValue());
            if (res.isSuccess && res != null){
                var caseDT = res.caseCreatedDate.substring(0, res.caseCreatedDate.length - 5);
                caseDT = caseDT + 'Z';
                component.set('v.caseCreatedDateTime', res.caseCreatedDate);
                component.set('v.caseNumber', res.caseNumber);
                component.set('v.emailId', res.emailId);
            } else {
                console.log('error retrieving case info');
            }
        });
        $A.enqueueAction(action);
    },
        
    handleReset: function(cmp, event, helper) {
        cmp.find('field').forEach(function(f) {
            f.reset();
        });
    },
    
    handleCreateProj : function(component, event, helper) {
        
        var invalidForm = false;
        var ipmStatusValue = component.find("ipmStatus").get("v.value");
        if(!ipmStatusValue || ipmStatusValue == '--None--'){
            document.getElementById('ipmStatusError').style.display = 'block';
            invalidForm = true;
        }
        else{
            document.getElementById('ipmStatusError').style.display = 'none';
        }
        if(invalidForm){
            return;
        }
        
        document.getElementById("loadingSpinner").style.display = "block";
        document.getElementById("mainForm").style.display = "none";
        component.find("projectForm").submit();
        var caseId = component.get("v.recordId");

        var action = component.get("c.CloseCase");
        action.setParams({
            "caseId": caseId
        });
        action.setCallback(this, function(data) {
            console.log('return value: ' + data.getReturnValue());
            
        });
        //$A.enqueueAction(action);
    },

    onRecSuccess : function(component, event, helper) {
        var payload = event.getParams().response;
        var recId = payload.id;
        console.log('record id ' + recId);

        var action = component.get('c.setEmailProject');
        action.setParams({
            "caseId": component.get('v.recordId'),
            "projId": recId
        });
        action.setCallback(this, function(data) {
            console.log('attempted to set Email project');
            console.log('return value: ' + data.getReturnValue());
        });
        $A.enqueueAction(action);


        var navEvt = $A.get("e.force:navigateToSObject");
        navEvt.setParams({
            "recordId": recId,
            "slideDevName": "Detail"
        });
        navEvt.fire();
        $A.get('e.force:refreshView').fire();
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": "Success!",
            "type": "success",
            "message": "The record has been created successfully."
        });
        //console.log('toastEvent: ' + toastEvent);
        toastEvent.fire();
        
    },

    onRecError : function(component, event, helper) {
        document.getElementById("loadingSpinner").style.display = "none";
        document.getElementById("mainForm").style.display = "block";
        var resultsToast = $A.get("e.force:showToast");
                resultsToast.setParams({
                    "title": "Error",
                    "type": "error",
                    "message": "There was a problem creating this Project. Please try again.",
                    "duration": 20000
                });
    },
    
    saveRec : function(component, event, helper) {       
                
        var newProj = component.get("v.proj");
        var newProjSerialized = JSON.stringify(newProj);
        
        var action = component.get("c.createProject");
        action.setParams({
            "jsonString" : newProjSerialized
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === 'SUCCESS') {
                $A.get('e.force:refreshView').fire();
                var resultsToast = $A.get("e.force:showToast");
                resultsToast.setParams({
                    "title": "Success",
                    "type": "success",
                    "message": "Project Created Successfully",
                    "duration": 20000
                });
                
            } else if (state === "ERROR") {
                
            }
            document.getElementById("loadingSpinner").style.display = "none";
        });
        $A.enqueueAction(action);
                
    },
    
    isFormValid: function (component, event, helper) {
        const requiredFields = component.find('ipmStatus') || [];
        var isValid = true;
        requiredFields.forEach(e => {
            if (e.get('v.value')=='' || e.get('v.value').trim().length==0 ) {
                isValid = false;
            }
        });
        return isValid;
	}
    
})