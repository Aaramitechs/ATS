({
    doInit: function(cmp) {
        window.open("https://app-us2.wrike.com/form/eyJhY2NvdW50SWQiOjUzNDE5NjMsInRhc2tGb3JtSWQiOjYyMjM3MH0JNDgxNzk4NzI3OTA0MAk0MTFkNGM0OGQyMTRlMDA1OGE1NGY2MjFlZWNmNDMwODc3YjlhOGEwNjE3NDUxNzkzZjk0MDg4YmQ0NDA5N2Q5");
    },
    
    onRender: function(cmp) {
    // Close the action panel
        //  var dismissActionPanel = $A.get("e.force:closeQuickAction");
        //  dismissActionPanel.fire();
        $A.get("e.force:closeQuickAction").fire();
    }
})