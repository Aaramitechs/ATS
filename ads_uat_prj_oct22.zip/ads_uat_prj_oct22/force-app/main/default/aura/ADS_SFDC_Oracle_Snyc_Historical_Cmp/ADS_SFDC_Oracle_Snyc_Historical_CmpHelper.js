({
    openModel: function(component, event, helper) {
        // Set isModalOpen attribute to true
        var action = component.get("c.getNotProcessedQuoteCount");
        action.setParams({
            "strStartDate": component.get("v.startDateStr"),
            "strEndDate": component.get("v.endDateStr")
        });
        action.setCallback(this, function(resp) {
            var state = resp.getState();
            if (state === "SUCCESS") {
                var res = resp.getReturnValue();
                if(!res.hasError){
                    if(res.quoteCount>0){
                        component.set('v.modalHeader', 'Do you want to proceed?');
                        component.set('v.modalContent', 'There are <b>'+res.quoteCount+'</b> Quotes and <b>'+res.quoteLineCount+'</b> Quote Line Items in selected date range. It will take some time to process. Please press \'Yes\' if you wish to proceed.');
                        component.set("v.isModalOpen", true);
                        component.set("v.hasMoreThanOneQuote", true);
                    } else{
                        component.set('v.modalHeader', 'No quote found');
                        component.set('v.modalContent', 'There is no Quote found in the selected date range. Please try again with other date range.');
                        component.set("v.isModalOpen", true);
                        component.set("v.hasMoreThanOneQuote", false);
                    }
                } else {
                    component.set('v.modalHeader', 'Information: Records are under process');
                    component.set('v.modalContent', 'System is already processing some records in backend, please try after sometime.');
                    component.set("v.isModalOpen", true);
                    component.set("v.hasMoreThanOneQuote", false);
                }
            } else{
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "title": "Error!",
                    "type": "error",
                    "message": "Some error has occoured, please contact System Administrator."
                });
                toastEvent.fire(); 
            }
        });
        // Send action off to be executed
        $A.enqueueAction(action);
        
    }
    
})