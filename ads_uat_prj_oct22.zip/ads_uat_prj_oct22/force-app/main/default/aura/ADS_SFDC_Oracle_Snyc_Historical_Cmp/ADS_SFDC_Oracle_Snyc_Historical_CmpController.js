({
    processHistoricalData: function(component, event, helper) {
        var startDate = component.get("v.startDate");
        var endDate = component.get("v.endDate");
        var title = "";
        var type = "";
        var message = "";
        var hasError = false;
        var toastEvent = $A.get("e.force:showToast");
        if((startDate == null || startDate == "") && (endDate == null || endDate == "")){
            title = "Warning!";
            type = "warning";
            message = "Please select the Date Range.";
            hasError = true;
        } else if(startDate == null || startDate == ""){
            title = "Warning!";
            type = "warning";
            message = "Please select the Start Date.";
            hasError = true;
        } else if(endDate == null || endDate == ""){
            title = "Warning!";
            type = "warning";
            message = "Please select the End Date.";
            hasError = true;
        } else if(startDate>endDate){
            title = "Warning!";
            type = "warning";
            message = "Start Date must be before End Date.";
            hasError = true;
        } else if(startDate == endDate){
            title = "Warning!";
            type = "warning";
            message = "Start Date and End Date cannot be same.";
            hasError = true;
        } else{
            var dateFormat = "yyyy-MM-dd";
            var userLocaleLang = $A.get("$Locale.LangLocale");
            component.set("v.startDateStr", $A.localizationService.formatDateTime(startDate, dateFormat, userLocaleLang));
            component.set("v.endDateStr", $A.localizationService.formatDateTime(endDate, dateFormat, userLocaleLang));
            helper.openModel(component, event, helper);
        }
        if(hasError){
            toastEvent.setParams({
                "title": title,
                "type": type,
                "message": message
            });
            toastEvent.fire(); 
        }
    },
    
    executeBatch: function(component, event, helper) {
        // Set isModalOpen attribute to false
        var toastEvent = $A.get("e.force:showToast");
        var action = component.get("c.processHistoricalQuote");
        action.setParams({
            "startDate": component.get("v.startDateStr"),
            "endDate": component.get("v.endDateStr")
        });
        action.setCallback(this, function(resp) {
            var state = resp.getState();
            if (state === "SUCCESS" && resp.getReturnValue() == 'Success') {
                toastEvent.setParams({
                    "title": "Success!",
                    "type": "success",
                    "message": "All the records in the date range are under process."
                });
                toastEvent.fire();
            } else{
                toastEvent.setParams({
                    "title": "Error!",
                    "type": "error",
                    "message": "Some error has occoured, please contact System Administrator."
                });
                toastEvent.fire(); 
            }
        });
        // Send action off to be executed
        $A.enqueueAction(action);
        component.set("v.isModalOpen", false);
    },
    
    closeModel: function(component, event, helper) {
        // Set isModalOpen attribute to false  
        component.set("v.isModalOpen", false);
    },
    
    showSpinner: function(component, event, helper) {
        // make Spinner attribute true for display loading spinner 
        component.set("v.Spinner", true); 
    },
    
    // this function automatic call by aura:doneWaiting event 
    hideSpinner : function(component,event,helper){
        // make Spinner attribute to false for hide loading spinner    
        component.set("v.Spinner", false);
    }
})