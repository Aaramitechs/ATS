({
    
    doInit : function(component, event, helper) {
       
        component.set("v.is_pass_Code_visible", false);

        var action = component.get("c.fetchLogedInUserDetails");
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var respns = response.getReturnValue();
                // set current user information on userInfo attribute
                component.set("v.userProInfo", respns);
                
                var pass_cd_acc_prfls = $A.get("$Label.c.Eng_Service_Fast_Pass_Profile_Access"); //$Label.c.Eng_Service_Fast_Pass_Profile_Access;
                
                if(pass_cd_acc_prfls.toLowerCase().trim().includes(respns.toLowerCase().trim())){
                    component.set("v.is_pass_Code_visible", true);
                }
            }
        });
        $A.enqueueAction(action);
        
    },  
    
    
    
    
    handleValueChange : function (component, event, helper) {
       	var fastPassReq_js = component.find("fastPassReq");
        var fastPassReq_jsValue = fastPassReq_js.get("v.checked");
        
        var cType = component.get('v.caseRec.Type');
        var cPrdType = component.get('v.caseRec.Product_Type__c');
        
        //alert('cType====>'+cType);
        //alert('cPrdType====>'+cPrdType);
        
        if(fastPassReq_jsValue && (cType!='Design Layout' || cPrdType !='StormTech')){
            
            var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
                title : 'Error',
                message:'You can only submit Fast Pass Requests for StormTech Design Layouts',
                duration:' 5000',
                key: 'info_alt',
                type: 'error',
                mode: 'pester'
            });
            toastEvent.fire();
            
            //alert('Error: You can only submit Fast Pass Requests for StormTech Design Layouts');
            var fastPassReq_js = component.find("fastPassReq");
            fastPassReq_js.set('v.checked', false);
            component.set('v.caseRec.Fast_Pass_Request__c', false);
        }if(fastPassReq_jsValue && cType == 'Design Layout' && cPrdType == 'StormTech'){
            component.set('v.caseRec.Fast_Pass_Request__c',fastPassReq_jsValue);
        }
        
    },
    
    
    handleValueChange_dsgnTolReq : function (component, event, helper) {
       	var designToolReq_js = component.find("designToolReq");
        var designToolReq_jsValue = designToolReq_js.get("v.checked");
        
        component.set('v.caseRec.Design_Tool_Request__c',designToolReq_jsValue);
        
        var cType = component.get('v.caseRec.Type');
        var cPrdType = component.get('v.caseRec.Product_Type__c');

        if(designToolReq_jsValue && (cType!='Design Layout' || cPrdType !='StormTech')){
            
            var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
                title : 'Error',
                message:'You can only submit Design Tool Request for StormTech Design Layouts',
                duration:' 5000',
                key: 'info_alt',
                type: 'error',
                mode: 'pester'
            });
            toastEvent.fire();
   
            var designToolReq_js = component.find("designToolReq");
            designToolReq_js.set('v.checked', false);
            component.set('v.caseRec.Design_Tool_Request__c', false);
        }if(designToolReq_jsValue && cType == 'Design Layout' && cPrdType == 'StormTech'){
            component.set('v.caseRec.Design_Tool_Request__c',designToolReq_jsValue);
        }
        
    }
    
    
})