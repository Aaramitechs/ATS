({
    doInit : function(component, event, helper){
        var recordId = component.get("v.recordId");
        
        var action = component.get("c.sendQLIToOracle");
        action.setParams({
            "quoteId": recordId
        });
        action.setCallback(this, function(resp) {
            var state = resp.getState();
            if (state === "SUCCESS") {
                var res = resp.getReturnValue();
                if(res != null && res.hasError == false){
                    $A.get("e.force:closeQuickAction").fire();
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Success!",
                        "type" : "Success",
                        "duration" : "8000",
                        "message": res.message
                    });
                    toastEvent.fire();
                } else if(res != null && res.hasError == true){
                    $A.get("e.force:closeQuickAction").fire();
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Error!",
                        "type" : "Error",
                        "duration" : "8000",
                        "message": res.message
                    });
                    toastEvent.fire();
                } else if(res != null && res.hasError == null){
                    $A.get("e.force:closeQuickAction").fire();
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Info!",
                        "type" : "Information",
                        "duration" : "8000",
                        "message": res.message
                    });
                    toastEvent.fire();
                }
            } else {
                $A.get("e.force:closeQuickAction").fire();
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "title": "Error!",
                    "type" : "Error",
                    "duration" : "8000",
                    "message": "Some error occurred, please try after sometime."+action.getReturnValue()
                });
                toastEvent.fire();
            }
        });
        // Send action off to be executed
        $A.enqueueAction(action);
    }
})