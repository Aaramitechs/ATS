({
    doInit : function(component, event, helper) {
        var action = component.get("c.initializeCases");
        
        action.setCallback(this, function(data) {
            component.set("v.listCase", data.getReturnValue());
            var baseCase = data.getReturnValue()[0];
            baseCase.Design__c = 'Simplified'; //Set default value for Design field.
            component.set("v.baseCase", data.getReturnValue()[0]);
        });
        $A.enqueueAction(action);
    },   
    
    handleSave: function(component, event, helper) {
        document.getElementById("Accspinner").style.display = "block";
        var requestedDate = component.find("requestedCompletionDate");
        var requestedDateValue = requestedDate.get("v.value");
        var requestedDateReason = component.find("requestedDateReason");
        var requestedDateReasonValue = requestedDateReason.get("v.value");
        //var numSystems = component.find("numberOfSystemsUnits");
        //var numSystemsValue = numSystems.get("v.value");
        var invalidForm = false;
        
        if(requestedDateValue && !requestedDateReasonValue){
            document.getElementById('dateReasonError').style.display = 'block';
            invalidForm = true;
        }
        if(!requestedDateValue && requestedDateReasonValue){
            document.getElementById('dateError').style.display = 'block';
            invalidForm = true;
        }
        if((requestedDateValue && requestedDateReasonValue) || (!requestedDateValue && !requestedDateReasonValue)){
            document.getElementById('dateReasonError').style.display = 'none';
            document.getElementById('dateError').style.display = 'none';
        }/*
        if(numSystemsValue == null){
            document.getElementById('numSystemsError').style.display = 'block';
            invalidForm = true;
        }
        else{
            document.getElementById('numSystemsError').style.display = 'none';
        }

        var specification = component.find("specification");
        var specificationValue = specification.get("v.value");
        if(!specificationValue || specificationValue == '--- None ---'){
            document.getElementById('specError').style.display = 'block';
            invalidForm = true;
        }
        else{
            document.getElementById('specError').style.display = 'none';
        }
        */
        var revision = component.find("revision");
        var revisionValue = revision.get("v.value");
        if(!revisionValue || revisionValue == '--- None ---'){
            document.getElementById('revError').style.display = 'block';
            invalidForm = true;
        }
        else{
            document.getElementById('revError').style.display = 'none';
        }

        var design = component.find("design");
        var designValue = design.get("v.value");
        if(!designValue || designValue == '--- None ---'){
            document.getElementById('desError').style.display = 'block';
            invalidForm = true;
        }
        else{
            document.getElementById('desError').style.display = 'none';
        }
        
        
        
        // Prepare the action to create the new contact
        var saveServiceRequestsAction = component.get("c.saveServiceRequests");
        var bCase = component.get("v.baseCase");
        bCase.sobjectType = 'Case';
        var bCaseSerialized = JSON.stringify(bCase);
        var lCase = component.get("v.listCase");
        lCase.sobjectType = 'Case[]';
        var lCaseSerialized = JSON.stringify(lCase);
        var projId = component.get("v.recordId");
        console.log('lCase: ', lCase);

        var hasInvalidCase = false;
        lCase.forEach(function (c){
            var notes = c.Notes_Rich_Text__c;
            //var notes = c.Notes__c;
            var reqType = c.Type;
            var prodType = c.Product_Type__c;
            var numSystemsValue = c.Number_of_Systems_Units__c;
            if(!notes || !reqType || !prodType || reqType == '--- None ---' || prodType == '--- None ---' ){
                //|| !numSystemsValue  // Rajj removed this logic for Ticket 202204-8911
                document.getElementById('tableError').style.display = 'block';
                hasInvalidCase = true;
                invalidForm = true;
            }
        });
        if(!hasInvalidCase){
            document.getElementById('tableError').style.display = 'none';
        }

        if(invalidForm){
            document.getElementById("Accspinner").style.display = "none";
            return;
        }

        saveServiceRequestsAction.setParams({
            "allCasesSerialized": bCaseSerialized,
            "listOfCasesSerialized": lCaseSerialized,
            "projectId": projId
        });

        // Configure the response handler for the action
        saveServiceRequestsAction.setCallback(this, function(response) {
            var state = response.getState();
            var caseNumber = response.getReturnValue();
            if(state === "SUCCESS") {

                // Prepare a toast UI message
                var resultsToast = $A.get("e.force:showToast");
                resultsToast.setParams({
                    "title": "Success",
                    "type": "success",
                    "message": "Master Case Record #: " + caseNumber,
                    "duration": 20000
                });

                component.set('v.errorMsg', '');

                // Update the UI: close panel, show toast, refresh account page
                $A.get("e.force:closeQuickAction").fire();
                resultsToast.fire();
                //$A.get("e.force:refreshView").fire();
            }
            else if (state === "ERROR") {
                let errors = response.getError();
                let message = 'Unknown error'; // Default error message
                // Retrieve the error message sent by the server
                if (errors && Array.isArray(errors) && errors.length > 0) {
                    message = errors[0].message;
                }
                // Display the message
                console.error(message);

                //display error in form
                component.set('v.errorMsg', message);

                /*// Configure error toast
                let toastParams = {
                    title: "Error",
                    message: message, // Default error message
                    type: "error"
                };
                // Fire error toast
                let toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams(toastParams);
                toastEvent.fire();*/
            }
            else {
                let message = 'Unknown error'; // Default error message
                // Retrieve the error message sent by the server
                if (errors && Array.isArray(errors) && errors.length > 0) {
                    message = errors[0].message;
                }

                //display error in form
                component.set('v.errorMsg', message);

                /*// Configure error toast
                let toastParams = {
                    title: "Error",
                    message: message, // Default error message
                    type: "error"
                };
                // Fire error toast
                let toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams(toastParams);
                toastEvent.fire();*/
            }
        });

        // Send the request to create the new Engineering Service Requests
        $A.enqueueAction(saveServiceRequestsAction);
    },

    handleCancel: function(component, event, helper) {
        $A.get("e.force:closeQuickAction").fire();
    },

    addCase : function(component, event, helper){
        var cases = component.get("v.listCase");
        var len = cases.length;
        cases.push({
        });
        component.set("v.listCase", cases);
        console.log('cases length: ', cases.length);
    }
})