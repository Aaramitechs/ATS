({
    init: function(component, event, helper){
        if (component.get('v.selectedRecord') != undefined && component.get('v.selectedRecord').Name != undefined){
            const lookupPill = component.find("lookup-pill");
            $A.util.addClass(lookupPill, 'slds-show');
            $A.util.removeClass(lookupPill, 'slds-hide');

            const searchResBox = component.find("searchRes");
            $A.util.addClass(searchResBox, 'slds-is-close');
            $A.util.removeClass(searchResBox, 'slds-is-open');

            const lookUpTarget = component.find("lookupField");
            $A.util.addClass(lookUpTarget, 'slds-hide');
            $A.util.removeClass(lookUpTarget, 'slds-show');
        }
    },

    onfocus : function(component,event,helper){
        $A.util.addClass(component.find("mySpinner"), "slds-show");
        const forOpen = component.find("searchRes");
        $A.util.addClass(forOpen, 'slds-is-open');
        $A.util.removeClass(forOpen, 'slds-is-close');
        // Get Default 5 Records order by createdDate DESC
        const inputKey = '';
        helper.searchHelper(component,event,inputKey);
    },
    onblur : function(component,event,helper){
        component.set("v.listOfSearchRecords", null );
        const forclose = component.find("searchRes");
        $A.util.addClass(forclose, 'slds-is-close');
        $A.util.removeClass(forclose, 'slds-is-open');
    },

    keyPressController : function(component, event, helper) {
        const inputKey = component.get("v.SearchKeyWord");
        if (inputKey.length > 0 ){
            const forOpen = component.find("searchRes");
            $A.util.addClass(forOpen, 'slds-is-open');
            $A.util.removeClass(forOpen, 'slds-is-close');
            helper.searchHelper(component,event,inputKey);
        }
        else{
            component.set("v.listOfSearchRecords", null );
            const forclose = component.find("searchRes");
            $A.util.addClass(forclose, 'slds-is-close');
            $A.util.removeClass(forclose, 'slds-is-open');
        }
    },

    clear :function(component,event,heplper){
        const pillTarget = component.find("lookup-pill");
        const lookUpTarget = component.find("lookupField");

        $A.util.addClass(pillTarget, 'slds-hide');
        $A.util.removeClass(pillTarget, 'slds-show');

        $A.util.addClass(lookUpTarget, 'slds-show');
        $A.util.removeClass(lookUpTarget, 'slds-hide');

        component.set("v.SearchKeyWord",null);
        component.set("v.listOfSearchRecords", null );
        component.set("v.selectedRecord", {} );
    },

    selectRecord : function (component, event, helper){
        const index = event.target.getAttribute("data-selected-Index");
        const records = component.get('v.listOfSearchRecords');
        const selectedRecord = records[index];
        if (selectedRecord != null){
            component.set("v.selectedRecord" , selectedRecord);
            component.set('v.recordId', selectedRecord.Id);
            const lookupPill = component.find("lookup-pill");
            $A.util.addClass(lookupPill, 'slds-show');
            $A.util.removeClass(lookupPill, 'slds-hide');

            const searchResBox = component.find("searchRes");
            $A.util.addClass(searchResBox, 'slds-is-close');
            $A.util.removeClass(searchResBox, 'slds-is-open');

            const lookUpTarget = component.find("lookupField");
            $A.util.addClass(lookUpTarget, 'slds-hide');
            $A.util.removeClass(lookUpTarget, 'slds-show');
        }
    }
})