declare module "@salesforce/resourceUrl/WebSubmissionIcon" {
    var WebSubmissionIcon: string;
    export default WebSubmissionIcon;
}