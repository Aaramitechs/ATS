declare module "@salesforce/resourceUrl/Web_Submission_Icon" {
    var Web_Submission_Icon: string;
    export default Web_Submission_Icon;
}