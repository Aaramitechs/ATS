declare module "@salesforce/resourceUrl/SalesQualityFeedbackProcess" {
    var SalesQualityFeedbackProcess: string;
    export default SalesQualityFeedbackProcess;
}