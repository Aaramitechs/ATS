declare module "@salesforce/resourceUrl/test_territories" {
    var test_territories: string;
    export default test_territories;
}