declare module "@salesforce/resourceUrl/truckicon" {
    var truckicon: string;
    export default truckicon;
}