declare module "@salesforce/resourceUrl/ADSLogoSmallFullColor" {
    var ADSLogoSmallFullColor: string;
    export default ADSLogoSmallFullColor;
}