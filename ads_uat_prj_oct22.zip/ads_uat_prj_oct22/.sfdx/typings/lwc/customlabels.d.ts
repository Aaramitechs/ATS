declare module "@salesforce/label/c.ADS_Distribution_List_Email_Address" {
    var ADS_Distribution_List_Email_Address: string;
    export default ADS_Distribution_List_Email_Address;
}
declare module "@salesforce/label/c.ADS_Mexicana_RTId" {
    var ADS_Mexicana_RTId: string;
    export default ADS_Mexicana_RTId;
}
declare module "@salesforce/label/c.ADS_Project_ClosedStatus" {
    var ADS_Project_ClosedStatus: string;
    export default ADS_Project_ClosedStatus;
}
declare module "@salesforce/label/c.CompanyBrand_ADS" {
    var CompanyBrand_ADS: string;
    export default CompanyBrand_ADS;
}
declare module "@salesforce/label/c.CompanyBrand_ADSM" {
    var CompanyBrand_ADSM: string;
    export default CompanyBrand_ADSM;
}
declare module "@salesforce/label/c.CompanyBrand_Cultec" {
    var CompanyBrand_Cultec: string;
    export default CompanyBrand_Cultec;
}
declare module "@salesforce/label/c.Cultec_ProfileName" {
    var Cultec_ProfileName: string;
    export default Cultec_ProfileName;
}
declare module "@salesforce/label/c.Eng_Service_Fast_Pass_Profile_Access" {
    var Eng_Service_Fast_Pass_Profile_Access: string;
    export default Eng_Service_Fast_Pass_Profile_Access;
}
declare module "@salesforce/label/c.Import_Lines_Format" {
    var Import_Lines_Format: string;
    export default Import_Lines_Format;
}
declare module "@salesforce/label/c.Reset_PowerUsers_Sandbox_Refresh" {
    var Reset_PowerUsers_Sandbox_Refresh: string;
    export default Reset_PowerUsers_Sandbox_Refresh;
}
declare module "@salesforce/label/c.SSO_PermissinoSetID" {
    var SSO_PermissinoSetID: string;
    export default SSO_PermissinoSetID;
}