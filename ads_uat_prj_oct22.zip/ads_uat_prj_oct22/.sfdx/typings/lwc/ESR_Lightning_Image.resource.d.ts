declare module "@salesforce/resourceUrl/ESR_Lightning_Image" {
    var ESR_Lightning_Image: string;
    export default ESR_Lightning_Image;
}