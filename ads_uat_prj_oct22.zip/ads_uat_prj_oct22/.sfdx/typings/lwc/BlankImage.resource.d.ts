declare module "@salesforce/resourceUrl/BlankImage" {
    var BlankImage: string;
    export default BlankImage;
}