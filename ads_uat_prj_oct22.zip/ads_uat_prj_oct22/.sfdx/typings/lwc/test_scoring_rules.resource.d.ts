declare module "@salesforce/resourceUrl/test_scoring_rules" {
    var test_scoring_rules: string;
    export default test_scoring_rules;
}