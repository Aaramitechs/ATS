declare module "@salesforce/apex/PicklistFieldController.getDependentOptionsImpl" {
  export default function getDependentOptionsImpl(param: {objApiName: any, contrfieldApiName: any, depfieldApiName: any}): Promise<any>;
}
