declare module "@salesforce/apex/AddMultipleServiceRequestsLightning.initializeCases" {
  export default function initializeCases(): Promise<any>;
}
declare module "@salesforce/apex/AddMultipleServiceRequestsLightning.saveServiceRequests" {
  export default function saveServiceRequests(param: {allCasesSerialized: any, listOfCasesSerialized: any, projectId: any}): Promise<any>;
}
declare module "@salesforce/apex/AddMultipleServiceRequestsLightning.processRequests" {
  export default function processRequests(param: {listOfCases: any, allCases: any, projectId: any}): Promise<any>;
}
declare module "@salesforce/apex/AddMultipleServiceRequestsLightning.generateRandomNumber" {
  export default function generateRandomNumber(param: {length: any}): Promise<any>;
}
declare module "@salesforce/apex/AddMultipleServiceRequestsLightning.fetchLogedInUserDetails" {
  export default function fetchLogedInUserDetails(): Promise<any>;
}
