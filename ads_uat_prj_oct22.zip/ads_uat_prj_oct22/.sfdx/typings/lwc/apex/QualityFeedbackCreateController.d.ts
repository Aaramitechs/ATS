declare module "@salesforce/apex/QualityFeedbackCreateController.getAccount" {
  export default function getAccount(param: {id: any}): Promise<any>;
}
