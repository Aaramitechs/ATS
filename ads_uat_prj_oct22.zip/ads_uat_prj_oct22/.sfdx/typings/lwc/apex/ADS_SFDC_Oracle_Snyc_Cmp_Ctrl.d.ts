declare module "@salesforce/apex/ADS_SFDC_Oracle_Snyc_Cmp_Ctrl.sendQLIToOracle" {
  export default function sendQLIToOracle(param: {quoteId: any}): Promise<any>;
}
