declare module "@salesforce/apex/PicklistSelectController.getFieldLabel" {
  export default function getFieldLabel(param: {objectName: any, fieldName: any}): Promise<any>;
}
declare module "@salesforce/apex/PicklistSelectController.getPicklistOptions" {
  export default function getPicklistOptions(param: {objectName: any, fieldName: any}): Promise<any>;
}
