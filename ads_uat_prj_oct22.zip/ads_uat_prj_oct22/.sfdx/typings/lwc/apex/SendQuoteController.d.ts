declare module "@salesforce/apex/SendQuoteController.sendQuoteDocument" {
  export default function sendQuoteDocument(param: {recordId: any, template: any, to: any, subject: any}): Promise<any>;
}
declare module "@salesforce/apex/SendQuoteController.renderTemplate" {
  export default function renderTemplate(param: {recordId: any}): Promise<any>;
}
declare module "@salesforce/apex/SendQuoteController.saveAttachment" {
  export default function saveAttachment(param: {parentId: any, name: any, base64Data: any, type: any}): Promise<any>;
}
