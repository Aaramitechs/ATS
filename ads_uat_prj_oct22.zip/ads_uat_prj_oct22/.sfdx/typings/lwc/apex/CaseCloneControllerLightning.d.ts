declare module "@salesforce/apex/CaseCloneControllerLightning.initializeCase" {
  export default function initializeCase(): Promise<any>;
}
declare module "@salesforce/apex/CaseCloneControllerLightning.cloneCase" {
  export default function cloneCase(param: {caseSerialized: any, caseId: any}): Promise<any>;
}
declare module "@salesforce/apex/CaseCloneControllerLightning.cloneProcessedCase" {
  export default function cloneProcessedCase(param: {caseRec: any, caseId: any}): Promise<any>;
}
