declare module "@salesforce/apex/EmailRecipentSearcher.fetchLookUpValues" {
  export default function fetchLookUpValues(param: {searchKeyWord: any, ObjectName: any}): Promise<any>;
}
