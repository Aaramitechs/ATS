declare module "@salesforce/apex/NewProjectController.CloseCase" {
  export default function CloseCase(param: {caseId: any}): Promise<any>;
}
declare module "@salesforce/apex/NewProjectController.getCaseFields" {
  export default function getCaseFields(param: {caseId: any}): Promise<any>;
}
declare module "@salesforce/apex/NewProjectController.setEmailProject" {
  export default function setEmailProject(param: {projId: any, caseId: any}): Promise<any>;
}
