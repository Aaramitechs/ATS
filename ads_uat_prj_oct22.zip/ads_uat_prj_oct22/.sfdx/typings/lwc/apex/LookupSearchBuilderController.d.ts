declare module "@salesforce/apex/LookupSearchBuilderController.fetchLookUpValues" {
  export default function fetchLookUpValues(param: {searchKeyWord: any, ObjectName: any, filter: any}): Promise<any>;
}
