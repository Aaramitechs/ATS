declare module "@salesforce/apex/Import_QuoteLines_LWCCntrl.importQLinesWithGroups" {
  export default function importQLinesWithGroups(param: {base64Data: any, recId: any, slctdGrpId: any}): Promise<any>;
}
declare module "@salesforce/apex/Import_QuoteLines_LWCCntrl.fetchExistingGroupsOfQuote" {
  export default function fetchExistingGroupsOfQuote(param: {qId: any}): Promise<any>;
}
