declare module "@salesforce/apex/ADS_SFDC_Oracle_Snyc_Historical_Ctrl.getNotProcessedQuoteCount" {
  export default function getNotProcessedQuoteCount(param: {strStartDate: any, strEndDate: any}): Promise<any>;
}
declare module "@salesforce/apex/ADS_SFDC_Oracle_Snyc_Historical_Ctrl.processHistoricalQuote" {
  export default function processHistoricalQuote(param: {startDate: any, endDate: any}): Promise<any>;
}
